import tkinter as tk
from tkinter import messagebox
import ipaddress

def calcular_rede():
    try:
        ip_rede = ip_entry.get()
        mascara_da_rede = mascara_entry.get()

        # Criando o objeto de rede
        rede = ipaddress.IPv4Network(f"{ip_rede}/{mascara_da_rede}", strict=False)

        # Calculando os resultados
        endereco_da_rede = rede.network_address
        primeiro_host_da_rede = list(rede.hosts())[0]
        ultimo_host_da_rede = list(rede.hosts())[-1]
        endereco_broadcast_da_rede = rede.broadcast_address

        classe_ip_da_rede = get_classe_ip(ip_rede)
        quantidade_subredes_da_rede = 2 ** (rede.prefixlen - 24) if rede.prefixlen > 24 else 1
        hosts_por_subrede_da_rede = 2 ** (32 - rede.prefixlen) - 2
        tipo_ip_da_rede = "Privado" if ipaddress.IPv4Address(ip_rede).is_private else "Público"

        # Exibindo os resultados na interface
        resultado_text.delete(1.0, tk.END)
        
        # Formatando o resultado como uma tabelinha
        resultado_text.insert(tk.END, f"{'Descrição':<30} {'Valor'}\n")
        resultado_text.insert(tk.END, f"{'-'*50}\n")
        resultado_text.insert(tk.END, f"{'Endereço de Rede:':<30} {endereco_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Primeiro Host:':<30} {primeiro_host_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Último Host:':<30} {ultimo_host_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Endereço de Broadcast:':<30} {endereco_broadcast_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Classe do IP:':<30} {classe_ip_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Quantidade de Sub-redes:':<30} {quantidade_subredes_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Hosts por Sub-rede:':<30} {hosts_por_subrede_da_rede}\n")
        resultado_text.insert(tk.END, f"{'Tipo de IP:':<30} {tipo_ip_da_rede}\n")

        # Bloqueando a modificação do campo de texto
        resultado_text.config(state=tk.DISABLED)

    except ValueError:
        messagebox.showerror("Erro", "Endereço IP ou Máscara Não Validos.")

def get_classe_ip(ip):
    primeiroocteto_da_rede = int(ip.split('.')[0])
    
    if 0 <= primeiroocteto_da_rede  <= 127:
        return "Classe A"
    elif 128 <= primeiroocteto_da_rede  <= 191:
        return "Classe B"
    elif 192 <= primeiroocteto_da_rede  <= 223:
        return "Classe C"
    else:
        return "Classe Invalida"


root = tk.Tk()
root.title("G.M.A Calculadora Ip")

root.geometry("600x600")

root.config(bg="#2E2E2E")

label_ip = tk.Label(root, text="Digite o Endereço IP:", fg="white", bg="#808080", font=("Arial", 13))
label_ip.pack(pady=5)

ip_entry = tk.Entry(root, width=30, font=("Arial", 13))
ip_entry.pack(pady=5)

label_mascara = tk.Label(root, text="Digite a Máscara de Sub-rede:", fg="white", bg="#2E2E2E", font=("Arial", 13))
label_mascara.pack(pady=5)

mascara_entry = tk.Entry(root, width=30, font=("Arial", 13))
mascara_entry.pack(pady=5)

calcular_button = tk.Button(root, text="Calcular", command=calcular_rede, bg="#b81414", fg="white", font=("Arial", 13), relief="raised")
calcular_button.pack(pady=15)


resultado_text = tk.Text(root, width=50, height=10, font=("Courier New", 14), bg="#1E1E1E", fg="white", padx=10, pady=10)
resultado_text.pack(pady=10)

root.mainloop()
